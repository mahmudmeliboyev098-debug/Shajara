# Shajara — oila daraxti

O‘zbekcha oilaviy shajara sayti. Ommaviy ko‘rish, egasi parol bilan kirib tahrirlashi, D1 bazasi va JSON zaxira imkoniyati bor. Tirik odamlar uchun tug‘ilgan kun/oy ommaviy ko‘rinishda yashiriladi. Sahifa `noindex` bilan belgilanadi.

## Muhim
Men loyihani tayyorlab berdim, ammo uni sizning Cloudflare/GitHub hisobingizga o‘zim joylay olmayman. Sayt internetda ishlashi uchun quyidagi bir martalik sozlash kerak.

## Cloudflare’ga chiqarish
1. ZIP’ni oching va ichidagi barcha fayl/papkalarni GitHub repozitoriyingizga yuklang (faqat ZIP faylining o‘zini emas).
2. Cloudflare Dashboard → Storage & databases → D1 SQL Database → Create database. Nomi `shajara-db` bo‘lsin.
3. Yaratilgan bazaning ID raqamini nusxalang. `wrangler.jsonc` faylida `PASTE_D1_DATABASE_ID_HERE` o‘rniga ID’ni qo‘ying.
4. Cloudflare Workers & Pages → Create → Import a repository orqali repozitoriyani ulang. Build command `npm run build`, deploy command `npx wrangler deploy`.
5. Birinchi deploydan so‘ng D1 bazasida migrations → `migrations/0001_init.sql` faylini ishga tushiring. Agar panel migrations’ni to‘g‘rөөрөө дэмжихгүй бол Cloudflare Dashboard → D1 → база → Console хэсэгт SQL файлын агуулгыг ажиллуулна.
6. Worker → Settings → Variables and Secrets дээр **Secret** төрлөөр `ADMIN_PASSWORD` (12+ тэмдэгт, бусад газар хэрэглэдэггүй) болон `BACKUP_TOKEN` (урт санамсаргүй утга) нэмнэ.
7. Дахин deploy хийнэ. Worker домэйнээ нээж `Kirish` товчоор паролоор орно.

## Автомат зөөврийн нөөц
GitHub → Settings → Secrets and variables → Actions дээр `SITE_URL` (жишээ нь `https://shajara.example.workers.dev`) болон `BACKUP_TOKEN` secret нэм. Actions → Haftalik zaxira → Run workflow дарж туршиж болно. Ням гараг бүр JSON backup шинэчлэгдэнэ.

## Локал туршилт
`npm install` дараа `npm run dev`. D1 local database-ийг `npx wrangler d1 migrations apply shajara-db --local` командаар үүсгэнэ.

## Хязгаарлалт
Энэ бол эхний хувилбар: зураг хадгалах талбарын API байгаа ч файл/зураг оруулах UI одоогоор хийгдээгүй. Олон хүний нэгэн зэрэг засварлах зориулалттай биш. Жинхэнэ гэр бүлийн мэдээлэл оруулахаасаа өмнө нөөц хуулбар болон нууц үгээ шалгаарай.
