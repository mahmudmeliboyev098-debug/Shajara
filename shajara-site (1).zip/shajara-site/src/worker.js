const json = (data, status = 200) => new Response(JSON.stringify(data), {status, headers: {'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
const clean = (s, max=160) => String(s ?? '').trim().slice(0,max);
function safePerson(row, isAdmin=false) {
  if (!row) return row;
  const alive = row.death_year == null;
  return {
    id: row.id, full_name: row.full_name, birth_year: row.birth_year,
    birth_month: isAdmin || !alive ? row.birth_month : null,
    birth_day: isAdmin || !alive ? row.birth_day : null,
    death_year: row.death_year, parent1_id: row.parent1_id, parent2_id: row.parent2_id,
    spouse: row.spouse, notes: row.notes, photo_data: row.photo_data
  };
}
async function isAdmin(request, env) {
  const token = request.headers.get('Authorization')?.replace(/^Bearer\s+/i,'');
  if (!token || !env.ADMIN_PASSWORD) return false;
  const a = new TextEncoder().encode(token), b = new TextEncoder().encode(env.ADMIN_PASSWORD);
  if (a.length !== b.length) return false;
  let diff = 0; for (let i=0;i<a.length;i++) diff |= a[i]^b[i]; return diff === 0;
}
async function readPeople(env) { return (await env.DB.prepare('SELECT * FROM people ORDER BY COALESCE(birth_year,9999), full_name').all()).results; }
async function api(request, env, url) {
  if (!env.DB) return json({error:'D1 bazasi sozlanmagan. README yo‘riqnomasini bajaring.'},500);
  if (url.pathname === '/api/login' && request.method === 'POST') {
    const body = await request.json().catch(()=>({}));
    if (!env.ADMIN_PASSWORD || typeof body.password !== 'string' || body.password !== env.ADMIN_PASSWORD) return json({error:'Parol noto‘g‘ri'},401);
    return json({token: body.password});
  }
  if (url.pathname === '/api/backup' && request.method === 'GET') {
    if (!env.BACKUP_TOKEN || request.headers.get('Authorization') !== `Bearer ${env.BACKUP_TOKEN}`) return json({error:'Ruxsat yo‘q'},401);
    return json({version:1, exported_at:new Date().toISOString(), people:await readPeople(env)});
  }
  if (url.pathname === '/api/restore' && request.method === 'POST') {
    if (!(await isAdmin(request,env))) return json({error:'Kirish kerak'},401);
    const body = await request.json().catch(()=>null);
    if (!body || !Array.isArray(body.people) || body.people.length > 2000) return json({error:'Zaxira fayli noto‘g‘ri'},400);
    await env.DB.prepare('DELETE FROM people').run();
    for (const p of body.people) await savePerson(env,p,true);
    return json({ok:true,count:body.people.length});
  }
  if (url.pathname === '/api/people' && request.method === 'GET') {
    const admin = await isAdmin(request,env); return json({people:(await readPeople(env)).map(p=>safePerson(p,admin))});
  }
  if (url.pathname === '/api/people' && request.method === 'POST') {
    if (!(await isAdmin(request,env))) return json({error:'Tahrirlash uchun Kirish qiling'},401);
    const p = await request.json().catch(()=>null); if (!p) return json({error:'Ma’lumot noto‘g‘ri'},400);
    return json({person:safePerson(await savePerson(env,p,false),true)},201);
  }
  const match = url.pathname.match(/^\/api\/people\/([\w-]+)$/);
  if (match && request.method === 'DELETE') {
    if (!(await isAdmin(request,env))) return json({error:'Tahrirlash uchun Kirish qiling'},401);
    await env.DB.prepare('DELETE FROM people WHERE id=?').bind(match[1]).run();
    await env.DB.prepare('UPDATE people SET parent1_id=NULL WHERE parent1_id=?').bind(match[1]).run();
    await env.DB.prepare('UPDATE people SET parent2_id=NULL WHERE parent2_id=?').bind(match[1]).run();
    return json({ok:true});
  }
  return json({error:'API manzili topilmadi'},404);
}
async function savePerson(env,p,restore=false) {
  const id = clean(p.id,80) || crypto.randomUUID();
  const name = clean(p.full_name,120); if (!name) throw new Error('Ism kiritilishi kerak');
  const num = v => v === '' || v == null ? null : Math.max(1,Math.min(9999,Number(v)||1));
  const vals = [id,name,num(p.birth_year),num(p.birth_month),num(p.birth_day),num(p.death_year),clean(p.parent1_id,80)||null,clean(p.parent2_id,80)||null,clean(p.spouse,120),clean(p.notes,1000),clean(p.photo_data,200000)];
  await env.DB.prepare(`INSERT INTO people (id,full_name,birth_year,birth_month,birth_day,death_year,parent1_id,parent2_id,spouse,notes,photo_data,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET full_name=excluded.full_name,birth_year=excluded.birth_year,birth_month=excluded.birth_month,birth_day=excluded.birth_day,death_year=excluded.death_year,parent1_id=excluded.parent1_id,parent2_id=excluded.parent2_id,spouse=excluded.spouse,notes=excluded.notes,photo_data=excluded.photo_data,updated_at=CURRENT_TIMESTAMP`).bind(...vals).run();
  return (await env.DB.prepare('SELECT * FROM people WHERE id=?').bind(id).first());
}
export default {
 async fetch(request,env) {
   const url = new URL(request.url);
   if (url.pathname.startsWith('/api/')) {
     try { return await api(request,env,url); }
     catch (e) { return json({error:e?.message || 'Ichki xato'},500); }
   }
   if (url.pathname === '/robots.txt') return new Response('User-agent: *\nDisallow: /\n',{headers:{'content-type':'text/plain'}});
   const response = await env.ASSETS.fetch(request);
   const headers = new Headers(response.headers); headers.set('X-Robots-Tag','noindex, nofollow, noarchive');
   return new Response(response.body,{status:response.status,headers});
 }
};
